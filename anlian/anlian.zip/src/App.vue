<template>
	<div>
    	<router-view></router-view>
    </div>
</template>

<script>
export default {};
</script>

<style>
body {
  color: #333;
  font-size: 28px;
  background-color: #f2f2f2;
  width: 100%;
  min-height: 100%;
  overflow-x: hidden;
}
.fn24 {
  font-size: 24px;
}
.fn28 {
  font-size: 28px;
}
.fn32 {
  font-size: 32px;
}
</style>
